##

import itertools

for i in itertools.count():    # if에서 무한루프를 돌리고 싶을 때.
    print("test")

## 한번에 입력받아 나누는 방법.

name, age, tel = \
    input("이름 나이 전화번호를 입력하세요 : ").split(sep = " ")

print(name)
print(age)
print(tel)