import math

name = "홍길동"
age = 100.222

print(int(age))
print(math.floor(age))
print(round(age, 1))                                             ## 소숫점 첫재자리 까지 올려줌(반올림)
print('나의 이름은 %s이고 나이는 %d' %(name, age))                 ## 타입을 써준다.
print('나의 이름은 {0}이고 나이는 {1:0.1f}'.format(name, age))     ## 괄호 안에는 자리 번호이다.