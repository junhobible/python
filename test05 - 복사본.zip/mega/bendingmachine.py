## 자판기

menu = ["사이다", "환타", "콜라", # 상품 종류
        "라떼", "아메리카노", "카푸치노", "홍차"]
price = [1000, 1000, 1000, 1000, 1500, 1500, 2000] # 각 상품의 가격
quan_menu = [20, 20, 20, 20, 20, 20, 20]
change = [500, 1000, 100] # 잔돈 종류
quan = [100, 100, 300]  # 잔돈 수량(500원, 1000원, 100원
## 라떼, 아메니카노, 카푸치노, 홍차는
# hot, cool을 나타내도록 고민하도록 한다.

while True:
    print("----------------------------------------------------")
    print("----------------더 조은 자판기-----------------------")
    for x in range(1, len(menu)+1):                      # 자판기 처음 모양
        print(str(x) + "." + menu[x-1] \
              + "(" + str(price[x-1]) + "원" + "/" \
              + str(quan_menu[x-1]) + "개)" , end=" ")
        if x % 2 == 0:
            print()
    print()
    print("----------------------------------------------------")
    # 돈을 입금한다.(결제 수단, 돈을 어떻게 넣을 지)
    how_to = int(input("결제 방법을 선택하세요 : 1.카드, 2.현금 >> "))
    if how_to not in [1, 2]:        # 1, 2 외 다른 것을 입력했을 때 처리
        print("잘 못 입력하셨습니다. 다시 입력하세요")
        how_to = int(input("결제 방법을 선택하세요 : 1.카드, 2.현금 >> "))
    if how_to == 1:         # 카드로 결제할 경우 잔돈은 없고 구매만 진행한다.
        choice = int(input("구매할 상품의 번호를 적어주세요 : ")) # 상품 선택
        if choice > 7 :
            choice = int(input("입력 오류, 다시 상품번호를 적으세요 : "))  # 상품 선택
        if quan_menu[choice -1] == 0:       ## 상품이 다 떨어질경우
            print("해당메뉴가 다 떨어졌습니다. 다른 것을 선택하세요")
            choice = int(input("구매할 상품의 번호를 적어주세요 : "))  # 상품 선택
        if choice in [4 , 5, 6, 7]:
            ice_hot = input("ice or hot ?")
            if ice_hot == "ice":            ## ice or hot 유무를 정한다.
                print("추가금액 500원이 추가됩니다.")
                print("ice" + menu[choice - 1] + "를 선택하셨습니다!")  # 상품이름 출력
                print("결제될 금액은" + str(price[choice - 1] + 500) + "입니다.")  # 구매결과 출력
                print("쿵 쾅 ~~!! " + menu[choice - 1] + "가 나왔습니다.")
                quan_menu[choice - 1] = quan_menu[choice - 1] - 1  # 구매수량 반영
                continue
        print(menu[choice-1] + "를 선택하셨습니다!")        # 상품이름 출력
        print("결제될 금액은" + str(price[choice - 1]) + "입니다.") # 구매결과 출력
        print("쿵 쾅 ~~!! " + menu[choice - 1] + "가 나왔습니다.")
        quan_menu[choice-1] = quan_menu[choice-1] - 1    # 구매수량 반영
        continue
    else:           ## 돈을 입금하는 경우
        money = int(input("돈을 입급하세요 : "))
        print(str(money) + "를 입금하셨습니다.!")
        while True :
            choice = int(input("구매할 상품의 번호를 적어주세요 : "))  # 상품 선택
            if money < price[choice -1]:  ## 돈이 모자랄 경우
                print("입금한 돈이 모자랍니다.")
                print("남은 잔액 : " + str(money) + "원")
                money = money + int(input("돈을 입급하세요 : "))  # 돈을 입금하고 기존 금액과 합친 금액을 보여준다.
                print("총 금액 : " + str(money))
                choice = int(input("구매할 상품의 번호를 적어주세요 : "))  # 상품 선택
            if quan_menu[choice - 1] == 0:  ## 상품이 다 떨어질경우
                print("해당메뉴가 다 떨어졌습니다. 다른 것을 선택하세요")
                choice = int(input("구매할 상품의 번호를 적어주세요 : "))  # 상품 선택
            if choice in [4, 5, 6, 7]:
                ice_hot = input("ice or hot ?")
                if ice_hot == "ice":
                    print("추가금액 500원이 추가됩니다.")
                    while money < price[choice -1] + 500:
                        print("돈이 부족합니다.")
                        money = money + int(input("돈을 입급하세요 : "))
                        print("잔액 :", money)
                    print("ice" + menu[choice - 1] + "를 선택하셨습니다!")  # 상품이름 출력
                    print("결제될 금액은" + str(price[choice - 1] + 500) + "입니다.")  # 구매결과 출력
                    print("쿵 쾅 ~~!! " + menu[choice - 1] + "가 나왔습니다.")
                    quan_menu[choice - 1] = quan_menu[choice - 1] - 1  # 구매수량 반영
                    money = money - (price[choice - 1] + 500)
                    print("남은 잔액은 :", money, "원 입니다.")
                    if money != 0:
                        question = input("더 구매하시겠습니까?(yes or no) >>")  # 추가구매 물어보기
                        if question == "yes":
                            print("----------------------------------------------------")
                            print("----------------더 조은 자판기-----------------------")
                            for x in range(1, len(menu) + 1):  # 자판기 처음 모양
                                print(str(x) + "." + menu[x - 1] \
                                      + "(" + str(price[x - 1]) + "원" + "/" \
                                      + str(quan_menu[x - 1]) + "개)", end=" ")
                                if x % 2 == 0:
                                    print()
                            print()
                            print("----------------------------------------------------")
                            continue
                        else:
                            print("남은 잔액은 :" + str(money))
                            print("잔돈이 반환됩니다.")
                            thou = money // 1000  # 잔돈의 각 수량을 알아내는 방법
                            five_hun = (money % 1000) // 500
                            hun = ((money % 1000) % 500) // 100
                            print("잔돈은", "천원 " + str(thou) + "장, " + \
                                  "오백원 " + str(five_hun) + "개, " + \
                                  "백원 " + str(hun) + "개")
                            change[0] = change[0] - thou
                            change[0] = change[0] - thou
                            change[1] = change[1] - five_hun
                            change[2] = change[2] - hun
                            print("안녕히 가세요!")
                            print("")
                            print("")
                            print("")
                            break
                    else:
                        thou = money // 1000  # 잔돈의 각 수량을 알아내는 방법
                        five_hun = (money % 1000) // 500
                        hun = ((money % 1000) % 500) // 100
                        print("잔돈은", "천원 " + str(thou) + "장, " + \
                              "오백원 " + str(five_hun) + "개, " + \
                              "백원 " + str(hun) + "개")
                        change[0] = change[0] - thou
                        change[0] = change[0] - thou
                        change[1] = change[1] - five_hun
                        change[2] = change[2] - hun
                        print("안녕히 가세요!")
                        print("")
                        break

            print(menu[choice - 1] + "를 선택하셨습니다!")  # 상품이름 출력
            print("결제될 금액은" + str(price[choice - 1]) + "입니다.")  # 구매결과 출력
            print("쿵 쾅 ~~!! " + menu[choice - 1] + "가 나왔습니다.")
            quan_menu[choice-1] = quan_menu[choice-1] - 1  # 구매수량 반영
            money = money - price[choice - 1]
            print("남은 잔액은 :", money, "원 입니다.")
            if money != 0:
                question = input("더 구매하시겠습니까?(yes or no) >>" ) # 추가구매 물어보기
                if question == "yes":
                    print("----------------------------------------------------")
                    print("----------------더 조은 자판기-----------------------")
                    for x in range(1, len(menu) + 1):  # 자판기 처음 모양
                        print(str(x) + "." + menu[x - 1] \
                              + "(" + str(price[x - 1]) + "원" + "/" \
                              + str(quan_menu[x - 1]) + "개)", end=" ")
                        if x % 2 == 0:
                            print()
                    print()
                    print("----------------------------------------------------")
                    continue
                else:       ## 잔돈이 남을 경우 잔액을 출력하고
                    print("남은 잔액은 :" + str(money))
                    print("잔돈이 반환됩니다.")
                    thou = money // 1000                # 잔돈의 각 수량을 알아내는 방법
                    five_hun = (money % 1000) // 500
                    hun = ((money % 1000) % 500) // 100
                    print("잔돈은", "천원 " + str(thou) + "장, " + \
                          "오백원 " + str(five_hun) + "개, " + \
                          "백원 " + str(hun) + "개")
                    change[0] = change[0] - thou
                    change[0] = change[0] - thou
                    change[1] = change[1] - five_hun
                    change[2] = change[2] - hun
                    print("안녕히 가세요!")
                    print("")
                    print("")
                    print("")
                    break
            else:       # 잔돈이 0인 경우
                print("남은 잔액은 :" + str(money))
                print("잔돈이 반환됩니다.")
                thou = money // 1000  # 잔돈의 각 수량을 알아내는 방법
                five_hun = (money % 1000) // 500
                hun = ((money % 1000) % 500) // 100
                print("잔돈은", "천원 " + str(thou) + "장, " + \
                      "오백원 " + str(five_hun) + "개, " + \
                      "백원 " + str(hun) + "개")
                change[0] = change[0] - thou
                change[1] = change[1] - five_hun
                change[2] = change[2] - hun
                print("안녕히 가세요!")
                print("")
                break

