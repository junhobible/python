# 극장예매 시스템 만들기

# 1. 화면을 만든다.


# 0이 10개 들어간 리스트 필요

seat = [0] * 10

name = input("이름을 입력하세요 : ")
while True:
    print("------------------------------------------")
    for x in range(1, len(seat)+1):
        print(x, end = "  ")

    print("\n------------------------------------------")
    for x in seat:
        print(x, end ="  ")
    print()
    print("------------------------------------------")
    choice = int(input('원하는 좌석 번호 입력(종료: -1) >> '))
    if choice > 10 or choice == 0:
        print("좌석번호를 초과하셨습니다.")
        print("다시 입력하세요")
        print()
        continue
    elif choice == -1:
        print("예매 프로그램을 종료합니다.")
        print()
        print(name + "님의 예매 확인 영수증")
        print("------------------------------------------")
        if seat.count(1) == 0:
            print("예매내역이 없습니다.")
            break
        else:
            print("선택 좌석 수 : ", end = " ")
            for x in range(0, len(seat)):    ## 요거 중요하니 잘 파악하기.
                if seat[x] == 1: print(str(x+1) + "번", end = " ")
            print()
            print("전체 예매된 좌석수는", seat.count(1), "좌석")
            print("결제 금액 : ", seat.count(1) * 10000)
            break
    else:
        if seat[choice-1] == 1:
            print("이미 예매가 된 좌석입니다.")
            print("다시 다른 좌석을 선택해주세요")
            print()
            continue
        else:
            print(choice, '를 선택하셨군요.')
            seat[choice-1] = 1              ## 입력받은 좌석번호 예매처리
            print("예매처리를 완료하였습니다.")
            print(seat.count(1), "개의 좌석이 예매되었습니다.")
            if seat.count(1) == 10:
                print("좌석이 모두 예매되었습니다. 예매를 종료합니다.")
                print("선택 좌석 수 : ", end=" ")
                for x in range(0, len(seat)):  ## 요거 중요하니 잘 파악하기.
                    if seat[x] == 1: print(str(x + 1) + "번", end=" ")
                print()
                print("전체 예매된 좌석수는", seat.count(1), "좌석")
                print("결제 금액 : ", seat.count(1) * 10000)
                break
            print()


## 개념 : 유닛테스트, 통합테스트












