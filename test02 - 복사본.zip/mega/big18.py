## 모듈 연습

from movie import price

price.info()
price.pay()