# 다른형태로 출력해보기(not console)
# 모든 프로그램은 입력, 처리, 출력의 형태로 생각한다.
# 이미 만들어 놓은 기능별 프로그램 단위 : module, 패키지 -> 파일 -> 세부기능별로 만들어 높음.
# "." : 접근 연산자(패키지 내에 세부 기능으로 들어간다.)
# 모듈을 사용하는 방법 3가지 -- > 내장모듈, 외장모듈, 직접제작

from tkinter import messagebox

messagebox.showinfo("안녕하세요.", "홍길동이요.")
messagebox.showwarning("error message", "you are wrong")
result = messagebox.askquestion("time check", "is it afternoon?")
print(result)





