# naver login

# 지하철을 타는 경우 1) 편해서, 2) 저렴해서
# all True(and 조건/"and"), one True(or 조건/"or"), not가 있다. --> 논리연산자

id = 'root'
pw = "pass"

id2 = input("아이디 입력 : ")
pw2 = input("패스워드 입력 : ")

if (id == id2 and pw == pw2):
    print("로그인 되셨습니다.")
else:
    print("id 혹은 password가 틀렸습니다.")



