# 콘솔에서 당신의 짝이름을 입력받으세요.
# 콘손에서 당신의 짝관심를 입력받으세요.
# 메세지 박스로 당신의 짝이름과 관심사를 확인하여 출력
# 관심사와 파이썬이라고 한다면, "프로그래머가 되실 거군요" 출력
# 아니라면 "데이터 분석가가 되실 거군요" 출력

from tkinter import messagebox

print("Let's play!")
name = input("what is your partner's name? : ")
inter = input("what is your partner's interest?(python or else) : ")

messagebox.showinfo("information", "name : " + name + " / interest : " + inter)
if inter == "python":
    messagebox.showinfo("information", "프로그래머가 되실 거군요")
else:
    messagebox.showinfo("information", "데이터분석가가 되실 거군요.")

