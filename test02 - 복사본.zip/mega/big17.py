# 계산기 모듈을 여기에서 쓰겠다.

from other import out01

out01.plus()
out01.minus()