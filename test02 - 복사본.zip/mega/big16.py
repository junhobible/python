#2.
from tkinter import messagebox

print("Let's play!")
name = input("what is your partner's name? : ")
inter = input("what is your partner's interest?(python or else) : ")
messagebox.showinfo("information", "name : " + name + " / interest : " + inter)
result = messagebox.askquestion("question", "파이썬이 확실한가요?")
if result == "yes":
    messagebox.showinfo("information", "열심히 하세요!")
else:
    messagebox.showinfo("information", "그럼 생각중이시군요!")