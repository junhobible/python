# 4번

id = "root"
input_id = input("로그인할 id를 입력 >> ")

if input_id == id :
    print("로그인 되었습니다.")
else:
    print("로그인되지 않았습니다.")

