# 반복문
# ctrl + / : 주석처리

# a = 10
# while a > 0:
#     print(a)
#     a = a - 1


# 1. 0부터 99까지 찍어보세요
# b = 100
#
# while b > 0:
#     print(100- b)
#     b = b - 1

# 2. 1부터 100까지 찍어보세요

# while b > 0:
#     print(101 - b)
#     b = b - 1

# 3. 1부터 100까지 중 짝수만 찍어보세요.
# b = 0
# while b < 100:
#     if(b % 2 ==0):
#         print(b)
#     b = b + 1

# 4. 0 부터 100까지 사이에 3의 배수를 찍어보세요.
# b = 0
# while b < 100:
#     if(b % 3 == 0):
#         print(b)
#     b = b + 1

#5. 0 ~ 99중 5의 배수의 개수를 구해보세요.
b = 0
cnt = 0
while b < 100:
    if(b % 5 == 0 and b != 0):
        cnt = cnt + 1
    b = b+1
print("5의 배수는", cnt, "개")

# 안녕하세요 5번 출력

# cnt = 1
#
# while cnt < 6:
#     print("안녕히가세요")
#     cnt = cnt + 1