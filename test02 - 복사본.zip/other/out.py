def call():
    print("나는 밖에 있는 함수 호출")
    print("인터넷에 접속해요")