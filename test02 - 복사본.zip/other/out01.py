# 계산기 기능

def mul():
    d1 = input("숫자입력 : ")
    d2 = input("숫자입력 : ")
    d1 = int(d1)
    d2 = int(d2)
    print(d1 + d2)

def plus():
    print("더하기 기능처리")
    a = int(input("숫자입력1 : "))
    b = int(input("숫자입력2 : "))
    print(a + b)

def minus():
    print("더하기 기능처리")
    a = int(input("숫자입력1 : "))
    b = int(input("숫자입력2 : "))
    print(a - b)



