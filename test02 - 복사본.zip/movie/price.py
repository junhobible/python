## price 함수

def info():
    name = input("같이 볼 사람의 이름은? : ")
    rel = input("같이 볼 사람과의 관계는? : ")
    print("**** 같이볼 사람의 이름 :", name,"/ "
                   "같이 볼 사람의 관계 :", rel,"****")

def pay():
    price = 10000
    cnt = int(input("인원수 입력(표당 1만원) : "))
    print("총금액:", price * cnt)


