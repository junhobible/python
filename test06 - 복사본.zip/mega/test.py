list2 = list[0] * 3
print(list2)