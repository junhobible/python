## 버튼 2개(저장, 읽어오기)
## 콘솔에 내용 출력
## 변수의 종류
# -------------------
# 기본형 변수    : 숫자, 문자열, 논리  ==> 그 해달 값이 변수에 저장
# 기본형이 아닌 변수    : 나머지 다, 부품(class, 객체)  ==> 주소가 변수에 저장

from tkinter import *
from tkinter.messagebox import *

# 함수 만들기

def file_write():
    print("입력합니다.")
    data = fruit_text.get()
    data = data.split()
    file1 = open("fruit.txt", 'w')
    print(data)
    for x in data:
        file1.write(x + '\n')
    file1.close()

def file_write_num():
    data = fruit_text.get()
    data = data.split()
    file1 = open("fruit.txt", 'w')
    for x in data:
        file1.write(x + '\n')
    file1.close()
    return len(data)

def file_read():
    print("출력합니다.")
    file2 = open("fruit.txt", 'r')
    list2 = []
    for x in range(0, file_write_num()):
        data = file2.readline()
        data = data.strip()
        list2.append(data)
    file2.close()
    print("과일 : ", end = "")
    print(list2)


# 전체 프레임 구성

w = Tk()
w.geometry("200x200")
w.configure(bg = "white")

# 입력지시창

fruit_label = Label(w, text = "과일 이름 입력기",
                    font = ('맑은 고딕', 20),
                    bg = 'lime',
                    fg = "blue")
fruit_label.pack()


# 입력창

fruit_text = Entry(w,
                   font = ("맑은 고딕", 10),
                   bg = "yellow",
                   fg = "blue")

fruit_text.pack()


# 버튼 만들기

button1 = Button(w, text = "입력",
                 bg = "pink",
                 font = ("궁서", 30),
                 command = file_write)  ## 괄호를 적지말기

button1.pack()

button2 = Button(w,
                 text = "출력",
                 bg = "pink",
                 font = ("궁서", 30),
                 command = file_read)  ## 괄호를 적어주지 말기
button2.pack()


# 끝날 때 반드시 마지막에
w.mainloop()
