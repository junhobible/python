## 새로운 예제

## 데이터 입력 , 배우고 싶은 과목 입력
## 자바, 파이썬, 머신러닝, 딥러닝(subject 리스트에 저장)


from tkinter import *
from tkinter.messagebox import *

# 1번 입력창 함수
def subject_write():
    data = text_input1.get()
    data = data.split()
    file = open("subject.txt", 'w')
    for x in data:
        file.write(x + "\n")
    print(data)
    file.close()
def subject_write_num():
    data = text_input1.get()
    data = data.split()
    file = open("subject.txt", 'w')
    for x in data:
        file.write(x + "\n")
    file.close()
    return len(data)
def subject_read():
    file2 = open("subject.txt", 'r')
    list = []
    for x in range(0, subject_write_num()):
        data = file2.readline()
        data = data.strip()
        list.append(data)
    file2.close()
    print(list)

# 2번 입력창 함수
def num_write():
    data = text_input2.get()
    data = data.split()
    file = open("number.txt", 'w')
    for x in data:
        file.write(x + "\n")
    print(data)
    file.close()


def num_write_num():
    data = text_input2.get()
    data = data.split()
    file = open("number.txt", 'w')
    for x in data:
        file.write(x + "\n")
    file.close()
    return len(data)


def num_read():
    file2 = open("number.txt", 'r')
    list = []
    for x in range(0, num_write_num()):
        data = file2.readline()
        data = int(data.strip()) + 10
        list.append(data)
    file2.close()
    print(list)

# 3번 입력창 함수
def hong_write():
    data = text_input3.get()
    data = data.split()
    file = open("hongbo.txt", 'w')
    for x in data:
        file.write(x + "\n")
    print(data)
    file.close()


def hong_write_num():
    data = text_input3.get()
    data = data.split()
    file = open("hongbo.txt", 'w')
    for x in data:
        file.write(x + "\n")
    file.close()
    return len(data)


def hong_read():
    file2 = open("hongbo.txt", 'r')
    list = []
    for x in range(0, hong_write_num()):
        data = file2.readline()
        data = data.strip()
        list.append(data)
    print(list)
    file2.close()

# 4번

# 5번 입력창 함수
def elec_write():
    data = text_input5.get()
    data = data.split()
    file = open("product.txt", 'w')
    for x in data:
        file.write(x + "\n")
    print(data)
    file.close()


def elec_write_num():
    data = text_input5.get()
    data = data.split()
    file = open("product.txt", 'w')
    for x in data:
        file.write(x + "\n")
    file.close()
    return len(data)

def elec_price_write():
    data = text_input6.get()
    data = data.split()
    file = open("last_price.txt", 'w')
    for x in data:
        file.write(x + "\n")
    print(data)
    file.close()


def elec_price_write_num():
    data = text_input6.get()
    data = data.split()
    file = open("last_price.txt", 'w')
    for x in data:
        file.write(x + "\n")
    file.close()
    return len(data)



def total_read():
    file = open("product.txt", 'r')
    file2 = open("last_price.txt", 'r')
    list = []
    list2 = []
    for x in range(0, elec_write_num()):
        data = file.readline()
        data = data.strip()
        list.append(data)
    for x in range(0, elec_price_write_num()):
        data2 = file2.readline()
        data2 = data2.strip()
        list2.append(data2)
    for x in range(0, len(list2)):
        print(list[x] + "은 " + list2[x] +"만원입니다.")
    file.close()
    file2.close()

def hong_read2():
    file3 = open("hongbo.txt", 'r')
    list2 = []
    for x in range(0, hong_write_num()):
        data = file3.readline()
        data = data.strip() + "짱"
        list2.append(data)
    file3.close()
    print(list2)

def total_read2():
    file = open("product.txt", 'r')
    file2 = open("last_price.txt", 'r')
    list = []
    list2 = []
    for x in range(0, elec_write_num()):
        data = file.readline()
        data = data.strip()
        list.append(data)
    for x in range(0, elec_price_write_num()):
        data2 = file2.readline()
        data2 = int(data2.strip()) + 10
        list2.append(data2)
    for x in range(0, len(list2)):
        print(list[x] + "은 " + str(list2[x]) +"만원입니다.")
    file.close()
    file2.close()


# 프레임 구축

w = Tk()
w.geometry("400x900")
w.configure(bg = "white")

# 제목
text_label = Label(w,
                   text = "통합 솔루션",
                   font = ("맑은 고딕", 30),
                   bg = "lime",
                   fg = "blue")

text_label.pack()

# 1번 입력창 및 버튼 구성(서브젝트)

# 1번 제목
text_label1 = Label(w,
                   text = "1.과목",
                   font = ("맑은 고딕", 15),
                   fg = "blue")

text_label1.pack()

# 1번 입력창
text_input1 = Entry(font = ("맑은 고딕", 10),
                    bg = 'white')

text_input1.pack()
button_sub1 = Button(text = '과목입력',
                 command = subject_write)
button_sub1.pack()

button_sub2 = Button(text = '과목출력',
                 command = subject_read)
button_sub2.pack()

# 2번 제목
text_label2 = Label(w,
                   text = "2.PLUS",
                   font = ("맑은 고딕", 15),
                   fg = "blue")

text_label2.pack()

# 2번 입력창
text_input2 = Entry(font = ("맑은 고딕", 10),
                    bg = 'white')

text_input2.pack()
button_num1 = Button(text = '숫자입력',
                 command = num_write)
button_num1.pack()

button_num2 = Button(text = '숫자출력',
                 command = num_read)
button_num2.pack()

# 3번 제목
text_label3 = Label(w,
                   text = "3.hongbo",
                   font = ("맑은 고딕", 15),
                   fg = "blue")

text_label3.pack()

# 3번 입력창
text_input3 = Entry(font = ("맑은 고딕", 10),
                    bg = 'white')

text_input3.pack()
button_hong1 = Button(text = '방법입력',
                 command = hong_write)
button_hong1.pack()

button_hong2 = Button(text = '방법출력',
                 command = hong_read)
button_hong2.pack()

# 4번 제목
text_label4 = Label(w,
                   text = "4.hongbo_plus",
                   font = ("맑은 고딕", 15),
                   fg = "blue")

text_label4.pack()

# 4번 입력창

button_plus = Button(text = '짱 추가하기',
                 command = hong_read2)
button_plus.pack()

# 5번 제목
text_label5 = Label(w,
                   text = "5.전자기기",
                   font = ("맑은 고딕", 15),
                   fg = "blue")

text_label5.pack()

# 5번 입력창
text_input5 = Entry(font = ("맑은 고딕", 10),
                    bg = 'white')

text_input5.pack()
button_elec1 = Button(text = '기기입력',
                 command = elec_write)
button_elec1.pack()

text_input6 = Entry(font = ("맑은 고딕", 10),
                    bg = 'white')

text_input6.pack()

button_price = Button(text = '가격입력',
                 command = elec_price_write)
button_price.pack()

button_total = Button(text = '종합출력',
                 command = total_read)
button_total.pack()

## 5번 마지막

button10 = Button(text = '가격인상',
                 command = total_read2)
button10.pack()

# 끝
w.mainloop()

