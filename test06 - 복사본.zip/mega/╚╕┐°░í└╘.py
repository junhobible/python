# 회원가입

from tkinter import *
from tkinter.messagebox import *

def insert():
    print("회원가입 함수가 호출됨")
    id = id_text.get()
    pw = pw_text.get()
    name = name_text.get()
    ph = ph_text.get()
    list = [id, pw, name, ph]
    list2 = ["id", "pw", "name", "ph"]

    print("당신의 넣은 데이터 확인====")
    for x in range(0, len(list)):
        print(list2[x] + " : " + list[x])
    custom = open(id + ".txt", "w")
    for x in list:
        custom.write(x + '\n')
    custom.close()

w = Tk()
w.geometry('500x600')
w.configure(bg = "white")

# 사진구간
icon = PhotoImage(file = 'naver.png') # 이미지로 부품화(객체화)시켜줌.
picture_label =  Label(w,
                  image = icon
                  )
picture_label.pack()


# 아이디 입력 문구
id_label = Label(w, text = "아이디 입력",
                 font = ("맑은 고딕", 20),
                 fg= "blue"
                 )
id_label.pack()

# 아이디 입력 창
id_text = Entry(w,
                font  = ("맑은 고딕", 20),
                bg = "yellow",
                fg = "red")
id_text.pack()

# 패스워드 입력 문구

pw_label = Label(w,
                 text = "패스워드 입력",
                 font = ("맑은 고딕", 20),
                 fg = "blue")
pw_label.pack()

# 패스워드 입력 창

pw_text = Entry(w,
                font = ("맑은 고딕", 20),
                bg = "yellow",
                fg = "red")
pw_text.pack()


# 이름 입력 문구

name_label = Label(w,
                 text = "이름 입력",
                 font = ("맑은 고딕", 20),
                 fg = "blue")
name_label.pack()

# 이름 입력 창

name_text = Entry(w,
                font = ("맑은 고딕", 20),
                bg = "yellow",
                fg = "red")
name_text.pack()

# 전화번호 입력 문구

ph_label = Label(w,
                 text = "전화번호 입력",
                 font = ("맑은 고딕", 20),
                 fg = "blue")
ph_label.pack()

# 번화번호 입력 창

ph_text = Entry(w,
                font = ("맑은 고딕", 20),
                bg = "yellow",
                fg = "red")
ph_text.pack()

# 회원가입처리

button = Button(w,
                text = "회원가입처리",
                font = ("맑은고딕", 15),
                bg = "pink",
                command = insert)
button.pack()


w.mainloop()