# 인기투표 시스템

# 우선 데이터를 입력받는다

list = []

print("지금부터 인기투표를 시작하겠습니다.")
while True:
    data = input("인기투표 대상자 입력(종료 x) >> ")
    if data == "x":
        print("인기투표 최종명단을 아래와 같습니다.")
        print(list, end = " ")
        print()
        print()
        break
    else:
        list.append(data)

# 투표를 시작한다.


# 각각의 사람마다 count를 세주면 된다.
data_score = [0] * len(list)
rank = [1] * len(list)

# 입력을 받는다.

while True:
    data = input("인기투표 시작(종료 x) : ")
    if data == 'x':
        print("투표가 종료됩니다.")
        print("최종결과 :", end = " ")
        for x in range(0,len(rank)):
            for y in range(0,len(data_score)):
                if data_score[x] < data_score[y]:
                    rank[x] = rank[x] + 1

        rank2 = [0] * len(list)
        for x in range(0, len(list)):
            rank2[rank[x] - 1] = x


        for i in range(0, len(list)):
            num = rank2[i]
            print(list[num] + "(" + str(data_score[num]) + ")," , end = " ")
        print()
        break
    else:
        for x in range(0, len(list)):
            if data == list[x]:
                data_score[x] = int(data_score[x]) + 1
