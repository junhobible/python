# 파일을 저장

movies = ['정직한 후보','작은 아씨들', '클로젯', '기생충', '수퍼 소닉']

# for-each
for x in movies:
    print(x, end = ' ')
print()

# for
for index in range(0, len(movies)):
    print(movies[index], end = ' ')
print()

# 리스트, 딕셔너리 등과 같은 collenction 계셩 내용 확인.

print(movies)
file = open('movie.txt', 'w')  # 읽기 : r , 쓰기 : w, 읽기 쓰기 : rw
                                # stream을 연다.
                                # fianance.naver.com site
                                # 사이트, 네트웤, db, file 연결 등 외부자원 연결
                                # => stream을 만들어야 한다.

file.write("내용이 들어갑니다.")

for data2 in movies:
    file.write(data2 + '\n')

# 일기를 입력(날짜, 제목, 날씨, 내용)
# 파일이름 : 날짜.txt, 위치는 mega아래로(default)
# 읽기를 쓸 때마다 날짜가 다르다.

if (input("id : ") == "root") and (input("pw : ") == '1234'):
    day = input("오늘의 날짜 : ")
    title = input("오늘의 제목 : ")
    weather = input("오늘의 날씨 : ")
    content = input("오늘의 내용 : ")
    list1 = [day, title, weather, content]

    diary = open(day + ".txt", 'w')

    for diary2 in list1:
        diary.write(diary2 + '\n')
else :
    print("아이디어와 패스워드가 맞지 않으면 일기를 쓸 수 없습니다.")

