# naver.login  화면 만들기

from tkinter import *
from tkinter.messagebox import *

# function(기능)
def login2():       # 특정한 객체에 함수를 연결(link, bind)
    print("login2 함수 호출됨")
    #1. 입력한 id, pw를 가지고 온다.
    id = id_text.get()
    pw = pw_text.get()

    #2. 입력한 id에 해당하는 file을 읽기 전용으로 스트림을 만든다.
    file_name = id + '.txt'
    file = open(file_name, 'r')
    #3. 파일에서 id, pw를 차례대로 읽어온 후 스트림을 받아준다
    id_saved = file.readline()
    pw_saved = file.readline()
    file.close()
    #4. 읽어 온후, 비교하기 전에 전처리(공백제거)
    id_saved = id_saved.strip()
    pw_saved = pw_saved.strip()
    #5. 비교 처리한 후 결과 출력
    if (id == id_saved and pw == pw_saved):
       showinfo("inforamtion", '로그인 ok....')
    else:
       showinfo('information', "로그인 not....")


def login():
    print("login함수 호출됨.")
    id = id_text.get()  ## get/set
    pw = pw_text.get()  ## get/set
    if(id == 'root' and  pw == '1234'):
        showinfo("inforamtion",'로그인 ok....')
    else :
        showinfo('information',"로그인 not....")



w = Tk()
w.geometry('500x400')       # 크기조절
w.configure(bg = 'lime')    # 배경

id_label =  Label(w,        # id 입력 지시문
                  text = "사용자 ID 입력: ",
                  font = ('맑은 고딕', 30),
                  bg = 'lime',
                  fg = 'blue'  # 앞에 보여지는 글자
                  )
id_label.pack()     # 자동으로 가운데로 정렬한다.
id_text = Entry(w,  # id 입력 창
                font = ('맑은 고딕', 30),
                bg = 'yellow',
                fg = 'red')

id_text.pack()      # id 정렬 시행문

pw_label =  Label(w,
                  text = "사용자 PW 입력: ",
                  font = ('맑은 고딕', 30),
                  bg = 'lime',
                  fg = 'blue'  # 앞에 보여지는 글자
                  )

pw_label.pack()     # pack 포장하다, 적절한 위치에 놓는 것
pw_text = Entry(w,
                font = ('맑은 고딕', '30'),
                bg = 'yellow',
                fg = 'red')
pw_text.pack()
icon = PhotoImage(file = 'login.png') # 이미지로 부품화(객체화)시켜줌.
button = Button(w, image = icon,
                command = login2) # 함수를 지정해준다.
button.pack()



w.mainloop() # 계속 창이 뜰 수 있도록 명령
