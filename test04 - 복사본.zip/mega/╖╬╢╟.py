import random

# 각 숫자가 달라야 되고
# 1 ~ 45 까지


lotto = []  # 랜덤으로 할당받을 로또 리스트를 선언

while len(lotto) < 6:  # 6개의 숫자가 받아질 대까지 계속 시행
    data = random.randint(1, 45)  # 랜덤 값 받아서
    if data not in lotto:       # 단, 조건은 기존 리스트에 그 숫자가 없어야 한다.
        lotto.append(data)      # 리스트에 선언

my_lotto = []   # 내가 선택할 숫자가 들어갈 리스트 선언

while len(my_lotto) != 6:       # 숫자 6이 되거 전까지 계속 시행
    data = int(input("원하는 숫자를 입력하세요 : "))      # 숫자를 하나씩 받는다.
    if data in my_lotto:                                 # 그 숫자가 기존 숫자와 중복될경우
        print("중복되었습니다. 다시 입력하세요.")
        continue                                         # 다시 처음으로 돌아간다.
    if data > 45:                                        # 입력한 숫자가 45이상일 경우
        print("값이 초과했습니다. 다시 입력하세요.")
        continue                                         # 다시 처음으로 돌아간다.
    my_lotto.append(data)                                # 모든 조건에 만족한 숫자만 리스트에 삽입


count = 0    # 맞힌 숫자를 세는 변수

for x in range(0, 6):
    if my_lotto[x] in lotto:
        count = count + 1
print("내 로또 : ", my_lotto)
print("당첩번호 공개", lotto)
print(count, "개 맞추었어요!")                            # 맞힌 개수를 적는다.

# for x in range(0, 6):
#     result = (my_lotto[x] == lotto[x])                   # 내가 선택한 로또와 당첨번호를 6번 비교
#     if result == True:                                   # 비교한 결과가 참일 경우
#         print("O", end = " ")                            # o를 출력하고 count를 올린다.
#         count = count + 1
#     else:
#         print("X", end = " ")                            # 틀릴 경우 x 출력
# print()

