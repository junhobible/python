# 17. 정답은 77입니다. 맞추는 게임을 완성하세요.
import random

aw = random.randint(1, 100) ## 100포함 되는 것.
count = 0
while True:
    count = count + 1
    data = int(input("당신이 생각한 정답 입력: "))
    if data == aw:
        print("정답입니다.")
        print("당신의 시도횟수 : ", count, '회')
        print("시스템을 종료합니다.")
        break
    else:
        if data < aw:
            print("틀렸습니다. 너무 작습니다.")
        elif data > aw:
            print("틀렸습니다. 너무 큽니다.")