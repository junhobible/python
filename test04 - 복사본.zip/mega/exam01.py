#1. 아이디와 이름을 입력받아 프린트
# 아이디가 root인 홍길동님이 로그인 되었습니다.

id = input("아이디를 입력 : ")
name = input("이름을 입력 : ")
print("아이디가 " + id +"인 " + name +"님이 로그인 되었습니다.")

# #
# #2. 두수를 입력받아 산술연산을 하여 프린트

num1 = int(input("숫자를 입력하세요 : "))
num2 = int(input("숫자를 입력하세요 : "))

print("------------------------------------")

print("두수의 합은", (num1 + num2))
print("두수의 차은", (num1 - num2))
print("두수의 곱은", (num1 * num2))
print("두수의 나눗셈은", (num1 / num2))
print("나누고서의 나머지는", (num1 % num2))

#3. 이름과 현재 나이를 입력받아서 다음과 같이 프린트
# 홍길동님의 10년 후의 나이는 110세입니다.

name2 = input("이름을 입력하세요 : ")
age = int(input("나이를 입력하세요 : "))
print(name2 + "님의 10년 후의 나이는", str((age + 10))+"세입니다.")

# 4.다음과 같이 판별 되도록 프린트(용돈)

wd = int(input("엄마 용돈 주세요 : "))
if wd > 10000:
    print("엄마 용돈이 너무 많아요")
else:
    print("엄마 용돈이 너무 적어요")
#
# 5.숫자 입력하여 짝 홀수 판별해보세요.
while True:
    num3 = int(input("숫자를 입력하세요(종료는 0) : "))
    if num3 == 0:
        break
    if num3 % 2 == 0:
        print("짝수입니다.")
    elif num3 % 2 != 0:
        print("홀수입니다.")

# 6.다음과 같이 처리되도록 코딩(실적목표 1000, 보너스 20% 단위 만원)

sell = int(input("당신의 실적을 입력하세요 : "))

if sell > 1000:
    print("축하합니다. 실적을 달성하셨습니다.")
    print("당신의 이번달 보너스는 ", 300*1.2,"입니다.")
else:
    print("목표에 도달하지 못했습니다.")
#
# 7. 미사일

ms = input("미사일 이름은 : ")
st = int(input("시작값은 : "))
sc = float(input("미사일 움직이는 값은 : "))

print("-----------------------------------")

print(ms, "미사일이", str(st + sc)+ "로 이동되었습니다.")

#8. 다음의 데이터를 입력받아, 영수증을 출력하세요.

list1 = ["받은돈", "총액", "부가세"]
list2 = []

for x in range(0,len(list1)):
    data = int(input(list1[x] + "을 입력하세요 : "))
    list2.append(data)

for x in range(0, len(list2)):
    print(list1[x] + ":", list2[x])
print("잔돈 :", list2[0] - (list2[1] + list2[2]) )

# 9. 별을 1000개 프린트(50개 20줄)

for x in range(0, 20):
    for y in range(0, 50):
        print("★", end = "")
    print()

# 10.
for x in range(0, 20):
    if(x == 0):
        for y in range(1, 21):
            print(y, end = " ")
        print()
    else:
        print(x+1)

# 11. 1부터 50까지 중 짝수만 프린트

for x in range(1, 51):
    if x % 2 == 0:
        print(x, end = " ")
print()

# 12. 1부터 1000까지 중 3의 배수의 개수 프린트
cnt = 0
for x in range(1, 1000):
    if x % 3 == 0:
        cnt = cnt + 1

print(cnt)


# 13. 원하는 만큼 입력할 수 있게 함.

list3 = []
while True:
    data = input("먹고싶은 음식을 입력(종료 x) : ")
    if data == "x":
        print("------------------------")
        print("입력을 종료합니다.")
        break
    list3.append(data)

# 14. 리스트에 먹고싶은 음식 5개를 넣으세요
print(list3)
print(list3[0], list3[-1])
print(list3[2])
print(list3[2:])

# 15. 빈 리스트를 만들어서 다음의 값을
# 하나씩 추가하여 프린트

list4 = []
while True:
    data = input("입력(종료 x) : ")
    if data == "x":
        print("------------------------")
        print("입력을 종료합니다.")
        break
    list4.append(data)
print(list4)

# 16. 리스트를 이용하여 다음과 같이 처리되도록 코딩
list5 =[]
for x in range(0,3):
    data = int(input("학기 총점 : "))
    list5.append(data)
print("------------------")
print("총학기 평균은", sum(list5)/len(list5))


# 17. 정답은 77입니다. 맞추는 게임을 완성하세요.

aw = 77
while True:
    data = int(input("당신이 생각한 정답 입력: "))
    if data == 77:
        print("정답입니다.")
        break
    else:
        print("틀렸습니다. 다시 입력하세요")

# 18. 은행 시스템

mon = int(input("입금액 : "))
inter = float(input("이자율 : "))
print("------------------------")
print("1년 후 받게될 금액은 :", str(mon * (1+inter) + "원"))
print()
print()
# 19. 나에 대한 5가지 정보를 딕셔너리에 넣어 전체 프린트
# 그 중 하나의 키에 대한 정보를 찾아 프린트

dic = {"이름" : "고준호", "나이" : 29, "주소" : "인천",
       "취미": "독서", "결혼": "무"}

print(dic["결혼"])

# 20. 내가 가장 좋아하는 장소를 좋아하는 순서대로
# 입력받아 다음과 같이 처리

site_list = []

for x in range(0, 5):
    site = input("장소 : ")
    site_list.append(site)
print("---------------------")
print(site_list)
if '강남' in site_list:
    print("강남있음")
    # del site_list[site_list.index("강남")]
    site_list.remove("강남")
print(site_list)
if '제주도' in site_list:
    print('제주도 있음')
    site_list[site_list.index("제주도")] = "제주시"
print(site_list)

for x in range(0, len(site_list)):
    print(str(x+1) + "등 :", site_list[x])


