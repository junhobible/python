import random



while True :
    my_choice = input("안내면 진 거 가위 바위 보 : ")
    if my_choice not in ['가위', '바위', '보']:
        print("잘 못 입력하셨습니다. 다시 입력하세요")
        continue
    if my_choice == "안해":
        print("종료합니다.")
        break

    choice = random.choice(["가위", "바위", "보"])
    # data = random.randint(1, 3)

    # if data == 1:
    #     choice = "가위"
    # elif data == 2:
    #     choice = "바위"
    # elif data == 3:
    #     choice = "보"
    print("컴퓨터:" , choice)
    if my_choice == "가위" :
        if choice == "가위":
            print("비겼습니다. 다시 내세요")
            continue
        elif choice == "바위":
            print("졌습니다.")
            repl = input("다시할가요?(yes or no) : ")
            if repl == "yes":
                continue
            else:
                break
        elif choice == "보":
            print("이겼습니다..")
            break

    if my_choice == "바위":
        if choice == "바위":
            print("비겼습니다. 다시 내세요")
            continue
        elif choice == "보":
            print("졌습니다.")
            repl = input("다시할가요?(yes or no) : ")
            if repl == "yes":
                continue
            else:
                break
        elif choice == "가위":
            print("이겼습니다.")
            break

    if my_choice == "보":
        if choice == "보":
            print("비겼습니다. 다시 내세요")
            continue
        elif choice == "가위":
            print("졌습니다.")
            repl = input("다시할가요?(yes or no) : ")
            if repl == "yes":
                continue
            else :
                break
        elif choice == "바위":
            print("이겼습니다.")
            break

