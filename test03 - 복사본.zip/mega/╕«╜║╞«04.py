

movies = [] ## 빈리시트

# 삽입(중간!), 추가(끝에!)
movies.append(100)
print(movies)
movies.append(200)
print(movies)
movies.append(300)
print(movies)
print(len(movies))\


