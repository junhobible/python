# 1문제

list1 = [100, 200, 300, 400, 500, 600 , 700, 800, 900]

for x in list1:
    print(x, end = ' ')
print()

print("-------------")

for x in range(0,len(list1),2):
    print(list1[x], end = " ")
print()

print("-------------")

sum = 0
for x in range(0,len(list1),2):
    sum = sum + list1[x]
print(sum)

print("-------------")


for x in range(1,len(list1),2):
    print(list1[x], end = " ")
print()

print("-------------")

# 2번째 문제
sum2 = 0
for x in range(1,10001):
    sum2 = sum2 + x
print(sum2)



