# 클라우드에서(다른환경)에서 분석환경으로 보낼 때 보통 dictionary로 보내게 된다.(tag와 비슷한 개념_

dic = {'apple': '사과', 'banana': '바나나', 'melon': '메론'}

print(dic)
print(dic.get("apple"))

# 1.

# set1 = set()
# i = 0
# while i < 3:
#     data = input("팀원을 입력하세요! : ")
#     set1.add(data)
#     i = i + 1
# print(set1)


# 2.

list1 =[]

i = 0
num1 = input("1등을 입력하세요 : ")
list1.append(num1)
num2 = input("2등을 입력하세요 : ")
list1.append(num2)
num3 = input("3등을 입력하세요 : ")
list1.append(num3)

print("2등이 반칙을 했습니다. 고로 탈락됩니다.")
del(list1[1])
print("1등 :", list1[0], "2등 :", list1[1])


#
# #3.

dic = {"1" : "엄마", "2":"아빠", "3":"친구","4번":"동생"}
print(dic.get("2"))



