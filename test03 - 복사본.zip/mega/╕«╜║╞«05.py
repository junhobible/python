# 연습문제

# score = []  ##
# i = 0
# sum = 0
# while i < 3:
#     data = input('점수를 입력하세요 : ')
#     score.append(int(data))
#     sum = sum + score[i]
#     i = i + 1
#
# print(score)
# print("합계 : ", sum)
# print('평균', sum / len(score))

# score.sort()    # 파괴적 함수 / 반환값이 없다.
# print(score)    # 비파괴적 함수

score = [] # 빈 리스트를 만든다.
i = 0  # 카운트
sum = 0     # 리스트 합계를 위한 변수

while i < 3: # 총 성적이 3개이기 때문에 3까지 한다.(index는 0부터 시작)
    data = input("성적을 입력하세요 : ") # 우선 성적을 입력받는다.
    score.append(int(data)) # 입력받은 값을 리스트에 넣되 수로 변환한다.
    sum = sum + score[i] # 처음 값은 기존 0과 더하여 덮어쓴다(총합)
    i = i + 1 # 다음 인덱스를 지정하기 위해 1을 더해준다.

print(score)   # 리스트 전체 출력
print("합계 : ", sum)     # 합계 출력
print("평균 : ", sum/len(score))      # 평균 출력
