# data = input("지금 먹고 싶은 것? 물, 아메리카노, 맥주 중 고르세요 : ")
# if data == '물':
#     print('밖으로 나가서 정수기로 갑니다.')
# elif data == '아메리카노':
#     print("이디아 가서 사먹는다.")
# elif data == '맥주':
#     pass
# else:
#     print('다시 제대로 입력해주세요')
#

import datetime
now = datetime.datetime.now()
hour = now.hour
print('현재는 : ', now)
print('현재 시각은: ', hour, '시')


    # time = int(input('지금 시각은? : '))
    # if time < 11:
    #     print('good morning!')
    # elif time < 17:
    #     print("good afternoon!")
    # elif time < 22:
    #     print("good evening!")
    # else:
    #     print("good night!")

# print('--------------------------')
#
# print('올해는 ', now.year, '년')
# print("현재달은 ", now.month,'월')
# print('오늘은', now.day, '일')
# print('현재는', now.day, '일')
# print('오늘은', now.day, '일')
# print('오늘은', now.day, '일')


