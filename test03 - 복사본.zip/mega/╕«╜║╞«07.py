food = ['라면', '커피', '아이스크림', '라떼', '팥빙수']

# 슬라이싱
print(food[0])
print(food[-1])
print(food[-2])
print(food[0:3])
print(food[2:])
print(food[:5])


print("---------------------")

drink = ['물', '아메리카도', '맥주']
all = food + drink
print(all)

print("---------------------")

drink3 = drink * 3   # 반복의 의미이다.
print(drink3)

print("---------------------")

drink.insert(0, '라떼')       # 파괴형
print(drink)

print("---------------------")

print(drink.index('라떼'))    # 비파괴형