# 한 줄 삭제 : ctrl + d

# name = ["홍길동", "박길동", "송길동"]
#
# print(name[0]) # 리스트 중 첫번째 값, 위치값
# print(name[1])
# print(name[2])
# print("-----------------")
#
# index = 0  # start 값
#
# while index < 3: # 조건문
#     print(name[index])
#     index = index + 1 # 증감식
#
# print("---------------------")
# print(name)
#
print("=====================")

age = [20, 25, 30]
# index = 0
# while index < 3:
#     print(age[index])
#     index = index + 1
# print(age)

print(len(age))  # 리스트의 개수 len(리스트명)

index2 =0

length = len(age)

while index2 < length:
    print(age[index2])
    index2 = index2 + 1

while index2 < len(age):
    print(age[index2])
    index2 = index2 + 1

print(age[len(age) - 1])  ## 리스트의 마지막값

