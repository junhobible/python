# 입력 : 홍길동
# 입력 : 파이썬
# 입력 : 프로그래머
# 입력 : 데이터분석가

# 홀길동은 파이썬 프로그래머 데이터분석가

# i = 0
# sum = ""
# while i < 4:
#     data = input("입력 : ")
#     sum = sum + " " + data
#     i = i + 1
#
# print(sum)

sum = ""
while True:
    data = input("입력(종료는 X) : ")
    if data == 'x' or data == 'X':
        print("반복문 종료를 진행합니다.")
        break
    sum = sum + " " + data

print(sum)