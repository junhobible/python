target = {1, 2, 3}

print(1 in target)  ## target 안에 1이 있는지 묻는 물음(boolean 반환)

target2 = [1,2,3,4,5]

for x in target2:
    print(x, end ='')
    print()

for x in range(0, len(target2), 2):
    print(target2[x], end = ' ')

