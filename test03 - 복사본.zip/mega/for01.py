subject = ['자바', '파이썬', 'R']
dic = {'apple': '사과', 'banana': '바나나', 'melon': '메론'}

team = {'디자이너', '프로그래머', 'db관리자'}
for x in team:           # 인덱스가 사라진다.
    print(x)

for x in dic:           # 키값만 찍힌다.
    print(x)
