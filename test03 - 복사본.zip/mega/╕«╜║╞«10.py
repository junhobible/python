# set(집합)

target = {1, 2, 3} #집합기호 중복 x

target.add(4) # 4는 중복안되기 때문에 추가
print(target)

target.add(2)
print(target)





