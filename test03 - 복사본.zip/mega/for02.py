# 3번 반복하고 싶은 경우.

# 한줄로 별 10개
for k in range(0, 10):   # default는 1씩 증가, 조정하려면 3번째 인수에 적어준다.
    # print(x)
    print('★', end=" ")
print()
print()

# 10줄로 별 10개
for x in range(0, 10):
    for k in range(0, 10):
        # print(x)
        print('★', end="")
    print("")

# 별 피라미드
for x in range(0, 10):
    for k in range(0, x):
    #print(x)
        print('★', end = "")
    print("")