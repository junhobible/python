import datetime

now = datetime.datetime.now()

## 많은 앙의 데이터가 있는 경우
# 순서 : list, # 읽기전용 : tuple(수정불가), # set(중복불가), # dictionary(키, 값)

#1
print(type(now.month))
if now.month < 2:
    print("2월 전이면 아직은 조금 춥겠군요.")
elif now.month == 2:
    print("2월이면 조금있으면 몸이 오겠군요.")
else:
    print("아니면 새해의 시작이 되겠군요.")

#2

if 3 <= now.month < 5:
    print("Spring!")
elif 5 < now.month < 8:
    print("Summer!")
elif 8 < now.month < 12:
    print("Fall!")
else:
    print("Winter!")

#3

if now.month == 2:
    print("2월은 28일이나 29일까지입니다.")
elif now.month == 1 or 3 or 5 or 7 or 8 or 10 or 11:
    print(now.month,"월은 31일 까지입니다.")
elif now.month == 2 or 4 or 6 or 11:
    print(now.month,"월은 30일 까지입니다.")

