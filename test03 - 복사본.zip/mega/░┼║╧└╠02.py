import turtle

# 코드 자동정리 --> ctrl + shift + f
pen = turtle.Pen()
pen.color('red')
pen.shape('turtle')
# pen.left(90)
# pen.forward(100)
#
# i = 0
# while i < 3 :
#     pen.right(90)
#     pen.forward(100)
#     i = i + 1

while True:
    choice = input("왼쪽 : 1, 오른쪽 : 2, 종료 : 3 >> ")
    if choice == '3':
        print("종료합니다.")
        break
    if choice == '1':
        pen.left(45)
        pen.forward(100)
    if choice == '2':
        pen.right(45)
        pen.forward(100)
