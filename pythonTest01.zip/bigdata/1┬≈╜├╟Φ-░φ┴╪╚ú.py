## 입출금 시스템
from tkinter import *
from tkinter import messagebox
list_deposit = []
name_list = [0] * 5

# 함수

# 이름입력 함수
def insert_name():
    if name_list[0] == text_input_name.get():  ## 이름이 동일할 때 처리(수정)
        messagebox.showinfo("information", "수정하겠습니다!")
        messagebox.showinfo("information", "수정할 금액을 입력하세요!")

        ## 수정할 때 새로운 창 등장!

        # 수정함수
        def insert_mody():
            deposit = text_input_deposit_mody.get()
            list_deposit[0] = deposit

        w2 = Tk()
        w2.geometry("100x100")
        w2.configure(bg="white")

        # 안내_수정
        text_label_name_mody = Label(w2, text="수정할 금액입력!",
                                font=('궁서', 10),
                                bg="white",
                                fg="blue")
        text_label_name_mody.pack()

        # 입력_수정
        text_input_deposit_mody = Entry(w2,
                                        font=('궁서', 20),
                                        bg='yellow')
        text_input_deposit_mody.pack()

        # 버튼_수정
        button_output_mody = Button(w2, text='제출',
                               font=('궁서', 10),
                               bg='pink',
                               command=insert_mody)
        button_output_mody.pack()
    else:                   ## 이름이 동일하지 않을 때!
        name = text_input_name.get()
        name_list[0] = name
        return name_list[0]

# 예금입력함수
def insert_depoist():
    deposit = text_input_deposit.get()
    list_deposit.append(deposit)


#출력함수
def output():
    if name_list[0] == 0:
        messagebox.showinfo("information", "이름을 아직 제출안했습니다.")
    else:
        list_deposit_str = ""
        for x in list_deposit:
            list_deposit_str = list_deposit_str + " " + x
        messagebox.showinfo("입력결과", name_list[0] + list_deposit_str)

#평균 출력함수
def sum_output():
    sum = 0
    for num in list_deposit:
        sum = sum + int(num)
    messagebox.showinfo("information", "합계 : " + str(sum) + " 평균 : " + str(sum/len(list_deposit)))

#종료함수
def exit_to_out():
    messagebox.showinfo("information", "종료하겠습니다!")
    exit()


# 시작
w = Tk()
w.geometry("500x500")
w.configure(bg = "white")

# 지시문구(맨 첫줄)
text_label = Label(text = "예금자와 예금액을 적으세요",
                   font = ('궁서', 30),
                   bg ="lime",
                   fg = "blue")

text_label.pack()

# 1. 라벨_이름
text_label_name = Label(text = "1.예금자(반드시 제출클릭!, 수정시 제출 다시클릭)",
                   font = ('궁서', 15),
                   bg ="white",
                   fg = "blue")

text_label_name.pack()

# 1.입력_이름
text_input_name = Entry(text = "이름",
                        font = ('궁서', 20),
                        bg = 'yellow')
text_input_name.pack()

# 1.버튼_이름
button_name = Button(text = '제출',
                     font = ('궁서', 10),
                     bg = 'pink',
                     command = insert_name)
button_name.pack()

# 2. 라벨_예금

text_label_deposit = Label(text = "2. 예금액(금액 한번 치고 제출 후 삭제후 다시 입력)",
                   font = ('궁서', 15),
                   bg ="white",
                   fg = "blue")

text_label_deposit.pack()

# 2. 입력_예금
text_input_deposit = Entry(text = "예금액",
                           font = ('궁서', 20),
                           bg = 'yellow')
text_input_deposit.pack()

# 2. 버튼_예금

button_deposit = Button(text = '제출',
                        font = ('궁서', 10),
                        bg = 'pink',
                        command = insert_depoist)

button_deposit.pack()

# 3. 라벨_출력(예금자와 예금액)

text_label_output = Label(text = "3.예금자, 예금액 출력!",
                   font = ('궁서', 25),
                   bg ="white",
                   fg = "blue")

text_label_output.pack()

# 3. 버튼_출력
button_output = Button(text = '출력',
                        font = ('궁서', 10),
                        bg = 'pink',
                        command = output)

button_output.pack()

# 4. 라벨_정리(합계와 평균)

text_label_sum = Label(text = "4.평균 합계 출력",
                   font = ('궁서', 25),
                   bg ="white",
                   fg = "blue")

text_label_sum.pack()

# 4. 버튼_정리
button_sum = Button(text = '출력',
                        font = ('궁서', 10),
                        bg = 'pink',
                        command = sum_output)

button_sum.pack()

# 5. 라벨_종료

text_label_exit = Label(text = "5.종료",
                   font = ('궁서', 25),
                   bg ="white",
                   fg = "blue")

text_label_exit.pack()

# 5. 버튼_종료
button_exit = Button(text = '종료',
                        font = ('궁서', 10),
                        bg = 'pink',
                        command = exit_to_out)

button_exit.pack()



# 마무리
w.mainloop()